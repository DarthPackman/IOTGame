#ifndef SIMONSAYS_H
#define SIMONSAYS_H

void SSSetup();
void SSLoop();

#endif
