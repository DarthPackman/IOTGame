#ifndef LIGHTCODE_H
#define LIGHTCODE_H

void LCSetup();
void LCLoop();

#endif