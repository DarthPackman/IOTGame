#ifndef LIGHTSOUT_H
#define LIGHTSOUT_H

void LOSetUp();
void LOLoop();
void LOClick(int index);
void LOSetUpClick(int index);
void LOUpdateLEDs();
bool LOCheckPlayerInput();
bool LOCheckPuzzleSolved();

#endif
