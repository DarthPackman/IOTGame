#ifndef WACKAMOLE_H
#define WACKAMOLE_H

void WAMSetupFunction();
void WAMLoop();

#endif